from django.urls import path
from . import views
# from app.views import CustomerList, CustomerDetails
from django.contrib import admin
from django.urls import path

urlpatterns = [
    # path('list/', views.CustomerList.as_view()),
    # path('details/', views.CustomerDetails.as_view())

   # path('customers/', views.CustomerMixinClass.as_view()),
    path('customers/', views.CustomerMixinClassID.as_view()),
    path('persons/', views.CustomerMixinClassPerson.as_view()),
]
