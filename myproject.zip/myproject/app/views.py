from django.shortcuts import render

# Create your views here.
# def Customer_list(request):
#   return


# def Customer_delete(request):
#   return


# from .models import Customer
# from .serializers import CustomerSerializer
# from rest_framework import generics


# class CustomerList(generics.ListAPIView):
#   queryset = Customer.objects.all()
#  serializer_class = CustomerSerializer


# class CustomerDetails(generics.RetrieveUpdateDestroyAPIView):
#   queryset = Customer
#  serializer_class = CustomerSerializer
from rest_framework.response import Response

from .models import Customer, Person
from .serializers import CustomerSerializer, PersonSerializer
from rest_framework import mixins, status
from rest_framework import generics


# class CustomerMixinClass(mixins.ListModelMixin,
#                           mixins.CreateModelMixin,
#                           generics.GenericAPIView):
#      queryset = Customer.objects.all()
#      serializer_class = CustomerSerializer
#
#      def get(self, request, *args, **kwargs):
#         return self.list(request, *args, **kwargs)
#
#      def post(self, request, *args, **kwargs):
#         return self.create(request, *args, **kwargs)
#
#########################################################################
# class CustomerMixinClassID(mixins.ListModelMixin,
#                            mixins.CreateModelMixin,
#                            mixins.UpdateModelMixin,
#                            mixins.DestroyModelMixin,
#                            generics.GenericAPIView):
#     queryset = Customer.objects.all()
#     serializer_class = CustomerSerializer
#
#     def get(self, request, *args, **kwargs):
#         return self.list(request, *args, **kwargs)
#
#     def put(self, request, *args, **kwargs):
#         return self.update(request, *args, **kwargs)
#
#     def post(self, request, *args, **kwargs):
#         return self.create(request, *args, **kwargs)
#
#     def delete(self, request, *args, **kwargs):
#         return self.destroy(request, *args, **kwargs)


############################################################################
class CustomerMixinClassPerson(
    generics.GenericAPIView,
    mixins.ListModelMixin,
    mixins.CreateModelMixin,
    mixins.UpdateModelMixin,
    mixins.DestroyModelMixin,
):
    queryset = Person.objects.all()
    serializer_class = PersonSerializer


    def filter_queryset(self, queryset):
        Person_id = self.request.data.get("id") or self.request.GET.get("id")
        if Person_id:
            return queryset.filter(id=Person_id)
        else:
            return queryset

    def get_object(self):
        queryset = self.get_queryset()
        Person_id = self.request.data.get("id") or self.request.GET.get("id")
        return queryset.get(id=Person_id)

    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return self.partial_update(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)


class CustomerMixinClassID(
    generics.GenericAPIView,
    mixins.ListModelMixin,
    mixins.CreateModelMixin,
    mixins.UpdateModelMixin,
    mixins.DestroyModelMixin,
):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer

    # permission_classes = (IsAdmin,)

    # def get_queryset(self):
    #     Customer_id = self.request.data.get(
    #         "Customer_id"
    #     ) or self.request.GET.get("Customer_id")
    #     return Customer.objects.filter(Person_id=Customer_id)

    def filter_queryset(self, queryset):
        Customer_id = self.request.data.get("id") or self.request.GET.get("id")
        if Customer_id:
            return queryset.filter(id=Customer_id)
        else:
            return queryset

    def get_object(self):
        queryset = self.get_queryset()
        Customer_id = self.request.data.get("id") or self.request.GET.get("id")
        return queryset.get(id=Customer_id)


    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return self.partial_update(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)
