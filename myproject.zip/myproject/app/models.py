from django.db import models


# Create your models here.


class Person(models.Model):
    title = models.CharField(max_length=100)

    def __str__(self):
        return self.title


class Customer(models.Model):
    name = models.CharField(max_length=100)
    phone_no = models.CharField(max_length=15)
    city = models.CharField(max_length=100)
    Person = models.ForeignKey(Person, on_delete=models.CASCADE,related_name='belong_to')

    def __str__(self):
        return self.name
