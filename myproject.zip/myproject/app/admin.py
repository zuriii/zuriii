from django.contrib import admin
from .models import Customer, Person
#
#
# # Register your models here.
#
# @admin.register(Person)
# class PersonAdmin(admin.ModelAdmin):
#     list_display = ['id', 'name', 'gender']
#
#
# @admin.register(Customer)
# class CustomerAdmin(admin.ModelAdmin):
#     list_display = ['id', 'name', 'phone_no', 'city', 'belong_to']

admin.site.register(Customer)
admin.site.register(Person)