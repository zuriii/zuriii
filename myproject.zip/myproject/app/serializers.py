from rest_framework import serializers
from .models import Customer, Person
from app.models import Customer


class PersonSerializer(serializers.ModelSerializer):
    class Meta:
        model = Person
        fields = "__all__"


class CustomerSerializer(serializers.ModelSerializer):
    Person = PersonSerializer(many=False, read_only=True)

    class Meta:
        model = Customer
        fields = ['id', 'name', 'phone_no', 'city', 'Person']



class PersonSerializer(serializers.ModelSerializer):

    belong_to = CustomerSerializer(many=True, read_only=True)

    class Meta:
        model = Person
        fields = ['id', 'title','belong_to']




